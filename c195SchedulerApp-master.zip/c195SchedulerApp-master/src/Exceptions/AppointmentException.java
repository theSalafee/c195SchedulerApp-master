package Exceptions;

/**
 *
 * @author Naasir the Salafee
 */
public class AppointmentException extends Exception {
    public AppointmentException(String exceptionMessage) {
        super(exceptionMessage);
    }
}