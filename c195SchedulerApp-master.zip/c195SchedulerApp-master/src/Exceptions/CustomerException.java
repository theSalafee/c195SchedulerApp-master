package Exceptions;

/**
 *
 * @author Naasir the Salafee
 *
 */
public class CustomerException extends Exception {
    public CustomerException(String exceptionMessage) {
        super(exceptionMessage);
    }
}