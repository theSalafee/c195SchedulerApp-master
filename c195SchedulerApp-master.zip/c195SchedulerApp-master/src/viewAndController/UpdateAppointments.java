package viewAndController;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class UpdateAppointments {
    public ComboBox contactField;
    public ComboBox AppointmentDescField;
    public TextField locationField;
    public DatePicker AppointmentDateField;
    public ComboBox AppointmentStartField;
    public ComboBox AppointmentEndField;
    public Button saveBtn;
    public Button cancelBtn;
    public TextField customerName;

    public void saveHandler(ActionEvent actionEvent) {
    }

    public void cancelHandler(ActionEvent actionEvent) {
    }
}
